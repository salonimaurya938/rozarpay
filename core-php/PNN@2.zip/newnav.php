
<div class="row " >
	<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=DAL" id="aa">दाल</a></button>
	<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=TEL" id="aa">तेल</a></button>
	<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=PMASALA" id="aa">पाउडर मसाला </a></button>
	<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=MASALA" id="aa">मसाला</button>
	


	<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=MEETA" id="aa">मिठास </a></button>
		<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=NASTA" id="aa"> नाश्ता </a></button>
	<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=BRAKFAST" id="aa">ब्रेकफास्ट</a></button>
<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=SARAF" id="aa">सरफ </a></button>	

<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=SABUN" id="aa">साबुन </a></button>
    
<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=SAIMFU" id="aa">शैम्पू </a></button>
    
<button type="button" class="btn btn-primary rounded n"><a href="product_category.php?proid=OTHER PRODUCT" id="aa">अन्य सामग्री</a></button>
    
</div>
<br><br>
