


		<!--=== Footer v4 ===-->
		<div class="footer-v4">




<!--div class="footer">
<div class="container">
<div class="row">
<div class="col-md-4 md-margin-bottom-40">
<a href="index.html"><img class="footer-logo" src="assets/img/logo-2.png" alt=""></a>
<p>About Unify dolor sit amet, consectetur adipiscing elit. Maecenas eget nisl id libero tincidunt sodales.</p>
<br>
<ul class="list-unstyled address-list margin-bottom-20">
<li><i class="fa fa-angle-right"></i>California, US, Lorem Lis Street, Orange, 25</li>
<li><i class="fa fa-angle-right"></i>Phone: 800 123 3456</li>
<li><i class="fa fa-angle-right"></i>Fax: 800 123 3456</li>
<li><i class="fa fa-angle-right"></i>Email: info@anybiz.co</li>
</ul>

<ul class="list-inline shop-social">
<li><a href="#"><i class="fb rounded-md fa fa-facebook"></i></a></li>
<li><a href="#"><i class="tw rounded-md fa fa-twitter"></i></a></li>
<li><a href="#"><i class="gp rounded-md fa fa-google-plus"></i></a></li>
<li><a href="#"><i class="yt rounded-md fa fa-youtube"></i></a></li>
</ul>
</div>
</div>
</div>
</div--><!--/footer-->




<div class="copyright">
<div class="container">
<div class="row">
<div class="col-md-6">
<p>
&copy; <?php echo date("Y") ?> - <?php echo $general[0];?>. ALL Rights Reserved.
</p>
</div>


<div class="col-md-6">
<p class="pull-right">
<a href="<?php echo $baseurl;?>/PrivacyPolicy.php">Privacy Policy</a> | <a href="<?php echo $baseurl;?>/tos.php">Terms of Service</a>
</p>
</div>



<!--div class="col-md-6">
<ul class="list-inline sponsors-icons pull-right">
<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
</ul>
</div-->
</div>
</div>
</div><!--/copyright-->






</div>
<!--=== End Footer v4 ===-->
</div><!--/wrapper-->





<!-- JS Global Compulsory -->
<script src="<?php echo $baseurl; ?>/assets/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/jquery/jquery-migrate.min.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- JS Implementing Plugins -->
<script src="<?php echo $baseurl; ?>/assets/plugins/back-to-top.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/smoothScroll.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/sky-forms-pro/skyforms/js/jquery.validate.min.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/jquery.parallax.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/owl-carousel/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/scrollbar/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script src="<?php echo $baseurl; ?>/assets/plugins/revolution-slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<!-- JS Customization -->
<script src="<?php echo $baseurl; ?>/assets/js/custom.js"></script>
<!-- JS Page Level -->
<script src="<?php echo $baseurl; ?>/assets/js/shop.app.js"></script>
<script src="<?php echo $baseurl; ?>/assets/js/plugins/style-switcher.js"></script>
<script src="<?php echo $baseurl; ?>/assets/js/forms/page_registration.js"></script>
<script src="<?php echo $baseurl; ?>/assets/js/plugins/owl-carousel.js"></script>
<script src="<?php echo $baseurl; ?>/assets/js/plugins/revolution-slider.js"></script>


	<script>
		jQuery(document).ready(function() {
			App.init();
			App.initScrollBar();
			Registration.initRegistration();
			StyleSwitcher.initStyleSwitcher();
		});
	</script>
<script>
	jQuery(document).ready(function() {
		App.init();
		App.initScrollBar();
		App.initParallaxBg();
		OwlCarousel.initOwlCarousel();
		RevolutionSlider.initRSfullWidth();
		StyleSwitcher.initStyleSwitcher();
	});
</script>