<?php
$mysqli=new mysqli("localhost","root","","ysfkbdxu_nwdbecrm");
$conn=new mysqli("localhost","root","","ysfkbdxu_nwdbecrm");
?>