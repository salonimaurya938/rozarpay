<?php
$mysqli=new mysqli("localhost","root","","ysfkbdxu_nwdbecrm");
?>